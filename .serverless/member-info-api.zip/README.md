# fi-settings-service
Service that returns the requested travel settings in accordance with the travelCTM GetMemberInfo API.  
